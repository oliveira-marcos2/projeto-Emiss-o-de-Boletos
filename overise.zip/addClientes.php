<?php

session_start();
  if(empty($_SESSION)){
    print "<script>location.href='index.php';</script>";
  }

  function limpar_texto($str){ 
    return preg_replace("/[^0-9]/", "", $str); 
  }

  if(count($_POST) > 0){

    include('conexao.php');
    $erro = false;
  
  
    $empresa = $_POST['empresa'];
    $email = $_POST['email'];
    $fone = limpar_texto($_POST['fone']);
    $cnpj = limpar_texto($_POST['cnpj']);
    
  
    if(empty($empresa)){
      $erro = "Preencha o Nome da Empresa";
    }
    if (!empty($fone)){
      $fone = limpar_texto($fone);
    }
    if(empty($email)){
      $erro = "Preencha o Email";
    }
    if(empty($cnpj)){
      $erro = "Preencha o CNPJ";
    }
    if ($erro){
      echo "<p><b>$erro</b></p>";
    }else{
      $sql_code = "INSERT INTO clientes (empresa, email, fone, cnpj) 
        VALUES('$empresa','$email','$fone','$cnpj')";
        
        $deu_certo = $conn->query($sql_code) or die($mysqli->error);
  
        if($deu_certo){
          print"<script>location.href='painel.php';</script>";
          unset($_POST);
        }
    }
  }

?>
<!DOCTYPE html>
<html lang="pt-br" >
<head >
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Cadastro Overise</title>
        <link rel="stylesheet" href="assets/css/app.min.css">
      
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>


<!-- Main Content -->
<div align="center" style="padding:20px; margin-top:40px;" >
 
        <div class="col-md-10"> 
      <section class="section" >


            <!-- inicio topo menu -->

            <?php

            require_once('dashboard.php');
            ?>
            <br>

            <?php
            
            require_once('topo.php');

            ?>
      
            <!-- fim topo menu -->


           <br>
         <!-- inicio formulario  topo menu -->
          <form action="" method="post" enctype="multipart/form-data">


         <div class="section-body" >
          <div class="row" >
            <div class="col-md-12">
              <div class="card">
                  
                    
                <div class="card-header">
                  <h4>Cadastro</h4><br>
                 
                </div>
                <div class="card-body">
         
                  <div class="form-group row mb-4">
                   
                    <div class="col-md-12">
                      <input type="text" class="form-control" name="empresa" placeholder="Nome Empresa">
                    </div>
                    
                  </div>

                  <div class="form-group row mb-4">
                   
                   <div class="col-md-12">
                     <input type="email" class="form-control" name="email" placeholder="e-mail">
                   </div>
                   
                 </div>

                 <div class="form-group row mb-4">
                   
                   <div class="col-md-12">
                     <input type="text" class="form-control" name="fone" placeholder="Telefone">
                   </div>
                   
                 </div>
                 <div class="form-group row mb-4">
                   
                   <div class="col-md-12">
                     <input type="text" class="form-control" name="cnpj" placeholder="CNPJ">
                   </div>
                   
                 </div>
                  <div class="form-group row mb-4">
                   
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-lg btn-primary"  style="width:100%;" name="SalvarCadastro" >Salvar</button>
                    </div>

                  </div>
                  <p><a href="">OVERISE</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
            </form>
      <!-- fim formulario  topo menu -->
      </section>
      </div>
        
       
    </div>

  <script src="assets/js/custom.js"></script>

 
  

</body>
</html>

