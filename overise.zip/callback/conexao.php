<?php
    define('HOST','localhost');
    define('USER','overis46_user');
    define('PASS','Facilmed1.');
    define('BASE','overis46_medfacil');

    $conn = new MySQLi(HOST, USER, PASS, BASE);