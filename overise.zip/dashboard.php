<div class="row">
    <div class="col-md-12">
        <div class="card mb-0">
            <nav class="navbar navbar-ligth bg-light">
              <div class="container-fluid">
                <a class="navbar-brand">OVERISE</a>
                <?php
                    print"Olá, ". $_SESSION["nome"];
                    print "<a href='index.php' class='btn btn-danger'>Sair</a>";
                ?>
              </div>
            </nav>
        </div>
    </div>
</div>