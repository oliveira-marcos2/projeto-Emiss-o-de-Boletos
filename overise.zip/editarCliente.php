<?php

session_start();
  if(empty($_SESSION)){
    print "<script>location.href='index.php';</script>";
  }


  include_once('conexao.php');
  $id = $_GET['id'];
  $sql_select = "SELECT * FROM clientes WHERE id=$id";
  $query_cliente = $conn->query($sql_select) or die($conn->error);;
  $cliente = $query_cliente->fetch_assoc();

  function limpar_texto($str){ 
    return preg_replace("/[^0-9]/", "", $str); 
  }


  if(count($_POST) > 0){

    $erro = false;
    $empresa = $_POST['empresa'];
    $email = $_POST['email'];
    $fone = limpar_texto($_POST['fone']);
    $cnpj = limpar_texto($_POST['cnpj']);

    if(empty($empresa)){
      $erro = print"<script>alert('Preencha o Nome da Empresa');</script>";
      print "<script>location.href='painel.php';</script>";
    }
    if(empty($fone)){
      $erro = print"<script>alert('Preencha o Telefone');</script>";
      print "<script>location.href='painel.php';</script>";
    }
    
    if(empty($email)){
      $erro = print"<script>alert('Preencha o Email');</script>";
      print "<script>location.href='painel.php';</script>";
    }
    if(empty($cnpj)){
      $erro = print"<script>alert('Preencha o CNPJ');</script>";
      print "<script>location.href='painel.php';</script>";
    }
    if ($erro){
      echo "<p><b>$erro</b></p>";
    }else{
      $sql_code = "UPDATE clientes 
      SET empresa = '$empresa', 
      email = '$email', 
      fone = '$fone', 
      cnpj = '$cnpj'
      WHERE id = '$id'";
        
        $deu_certo = $conn->query($sql_code) or die($mysqli->error);
  
        if($deu_certo){
          unset($_POST);
          print"<script>location.href='painel.php';</script>";
        }
    }
  }

?>
