<?php

session_start();
  if(empty($_SESSION)){
    print "<script>location.href='index.php';</script>";
  }

function limpar_texto($str){ 
  return preg_replace("/[^0-9]/", "", $str); 
}



?>

<!DOCTYPE html>
<html lang="pt-br">
<head >
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Gerador de Boletos</title>
        <link rel="stylesheet" href="assets/css/app.min.css">
      
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>

<!-- Main Content -->
<div align ="center" style="padding:20px; margin-top:40px;" >
 
        <div class="col-md-10"> 


            <!-- inicio topo menu -->
            <?php

            require_once('dashboard.php');
            ?>
            <br>
            <?php
            
            require_once('topo.php');

            ?>
      
            <!-- fim topo menu -->


           <br>
          <!-- INICIO TABELA -->
          <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Ativos</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped table-hover" id="save-stage" style="width:100%;">
                        <thead>
                          <tr>
                            <th>Nº</th>
                            <th>Criado</th>
                            <th>Empresa</th>
                            <th>Telefone</th>
                            <th>E-mail</th>
                            <th>CNPJ</th>
                            <th>Editar</th>
                            <th>Excluir</th>
                           
                          </tr>
                        </thead>
                        <tbody>
                           
                            <?php
                                include('conexao.php');
                                $sql_cliente = "SELECT * FROM clientes ORDER BY data DESC";
                                $query_cliente = $conn -> query($sql_cliente) or die($conn->error);
                                while($cliente = $query_cliente->fetch_assoc()){


                                  ?>

                                <tr>
                                  <td><?php echo $cliente['id']?></td>
                                  <td><?= date('d/m/Y',strtotime($cliente['data'])) ?></td>
                                  <td>
                                    <button type="button" class="btn btn-icon btn-primary" data-toggle="modal" data-target="#Boleto<?php echo $cliente['id'] ?>" data-whatever="@mdo"><?php echo $cliente['empresa'] ?></button>
                                  </td>
                                  <td><?php echo $cliente['fone'] ?></td>
                                  <td><?php echo $cliente['email'] ?></td>
                                  <td><?php echo $cliente['cnpj'] ?></td>
                              
                                  <td>
                                    <button type="button" class="btn btn-icon btn-primary" data-toggle="modal" data-target="#atualizarCliente<?php echo $cliente['id'] ?>" data-whatever="@mdo"><i class="far fa-edit"></i></button>
                                  </td>
                                  <td>
                                      <button type="button" class="btn btn-icon btn-danger" data-toggle="modal" data-target="#excluirCliente<?php echo $cliente['id'] ?>" data-whatever="@mdo"><i class="fas fa-trash-alt"></i></button>
                                  </td>
                                


                                  <!-- Modal Atualizar Cliente -->

                                <div class="modal fade" id="atualizarCliente<?php echo $cliente['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Atualizar Cliente</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <form action="editarCliente.php?id=<?php echo $cliente['id'] ?>" method="post">
                                          <div style='text-align:left'>
                                            <label for="recipient-name" class="col-form-label">Empresa:</label>
                                            <input type="text" class="form-control" name="empresa" value="<?php echo $cliente['empresa'] ?>" placeholder="Nome Empresa">
                                          </div>
                                          <div style='text-align:left'>
                                            <label for="recipient-name" class="col-form-label">Email:</label>
                                            <input type="email" class="form-control" name="email" value="<?php echo $cliente['email'] ?>" placeholder="e-mail">
                                          </div>
                                          <div style='text-align:left'>
                                            <label for="recipient-name" class="col-form-label">Fone:</label>
                                            <input type="text" class="form-control" name="fone" value="<?php echo $cliente['fone'] ?>" placeholder="Telefone">
                                          </div>
                                          <div style='text-align:left'>
                                            <label for="recipient-name" class="col-form-label">CNPJ:</label>
                                            <input type="text" class="form-control" name="cnpj" value="<?php echo $cliente['cnpj'] ?>" placeholder="CNPJ">
                                          </div>

                                      
                                          <div class="modal-footer">
                                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                              <input type="hidden" name="id" value="<?php $cliente['id'] ?>">
                                              <button type="submit" value="atualizar" name="atualizar" class="btn btn-primary">Salvar</button>
                                          </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>


                                  <!-- Modal Excluir Cliente -->
                                <div class="modal fade" id="excluirCliente<?php echo $cliente['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Deletar Cliente</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <form action="deletarCliente.php?id=<?php echo $cliente['id'] ?>" method="post">

                                          <div style='text-align:left'>
                                            <label for="recipient-name" class="col-form-label">Deseja realmente excluir o cliente:<h5> <?php echo $cliente['empresa'] ?></h5>  </label>
                                          </div>

                                      
                                          <div class="modal-footer">
                                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                              <input type="hidden" name="id" value="<?php $cliente['id'] ?>">
                                              <button type="submit" value="deletar" name="deletar" class="btn btn-primary">Salvar</button>
                                          </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                
                                <!-- Modal Boletos -->
                                <div class="modal fade" id="Boleto<?php echo $cliente['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Boletos</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                        <form action="" method="post">
                                          <div class="modal-header">
                                            <p>Numero Boleto</p>
                                            <p>Status</p>
                                            <p>Data Vencimento</p>
                                          </div>

                                        <?php
                                          $id = $cliente['id'];
                                          $sql3 = "SELECT * FROM pagamento WHERE id_usuario = $id";
                                          $query_pagamento = $conn -> query($sql3) or die($conn->error);
                                          while($pagamento = $query_pagamento->fetch_assoc()){
                                        ?>
                                          <div class="modal-header" style='text-align:left'>

                                            <label for="recipient-name" class="col-form-label"><h5> <?php echo $pagamento['id_efi'] ?></h5></label><br>
                                            <label for="recipient-name" class="col-form-label"><?php echo $pagamento['status_cobranca'] ?></label><br>
                                            <label for="recipient-name" class="col-form-label"><?php echo $pagamento['data_venc'] ?></label>
                                            
                                          </div>
                                        <?php

                                          }
                                        ?>

                                      
                                          <div class="modal-footer">
                                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                          </div>
                                        </form>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                    

                                <?php

                                }
                               
                                
                            ?>

                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>


          
      <!-- fim tabela-->
      </div>
        
       
    </div>

  <script src="assets/js/custom.js"></script>

    <!-- JavaScript (Opcional) -->
    <!-- jQuery primeiro, depois Popper.js, depois Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>