<?php
session_start();
if(empty($_SESSION)){
  print "<script>location.href='index.php';</script>";
}

$autoload = realpath(__DIR__ . "/vendor/autoload.php");
if (!file_exists($autoload)) {
	die("Autoload file not found or on path <code>$autoload</code>.");
}
require_once $autoload;

use Efi\Exception\EfiException;
use Efi\EfiPay;

$gerar = filter_input_array(INPUT_POST, FILTER_DEFAULT);

if(isset($gerar['gerarBoleto'])){
    unset($gerar['gerarBoleto']);
    
    include('conexao.php');
        $sql_cliente = "SELECT * FROM clientes ORDER BY data DESC";
        $query_cliente = $conn -> query($sql_cliente) or die($conn->error);
        $cliente = $query_cliente->fetch_assoc();

    $vencimento = date('d/m/Y', strtotime($gerar['data']));

    $cnpj = preg_replace('/\W+/u','', $cliente['cnpj']);

    //echo "Nome: {$cliente->nome} data: {$vencimento} plano: {$gerar['plano']} Valor: {$gerar['valor']}";



    $options = [
        "clientId" => "Client_Id_ee4dcaf07a6aec70de79422a3b7ff7afb9e95c36",
        "clientSecret" => "Client_Secret_8e0dd784a38d42e66f6c08a57229ed4de873df92",
        //"certificate" => realpath(__DIR__ . "/arquivoCertificado.p12"), // Caminho absoluto para o certificado no formato .p12 ou .pem
        //"pwdCertificate" => "", // Opcional | Padrão = "" | Senha de criptografia do certificado
        "sandbox" => true, // Opcional | Padrão = false | Define o ambiente de desenvolvimento entre Produção e Homologação
        //"debug" => false, // Opcional | Padrão = false | Ativa/desativa os logs de requisições do Guzzle
        "timeout" => 30, // Opcional | Padrão = 30 | Define o tempo máximo de resposta das requisições
    ];

$items = [
	[
		"name" => $gerar['plano'],
		"amount" => 1,
		"value" => intval($gerar['valor'])
	],
	
];

$metadata = [
	//"custom_id" => "Order_00006",
	"notification_url" => "https://www.overise.com.br/callback/retornoBoleto.php"
];

$customer = [
	//"name" => $cliente['empresa'],
	//"cpf" => $cpf,
	"email" => $cliente['email'],
	// "phone_number" => "",
	// "birth" => "",
	"juridical_person" => [
 	"corporate_name" => $cliente['empresa'],
	"cnpj" => $cnpj
	 ],
	// "address" => [
	// 	"street" => "",
	// 	"number" => "",
	// 	"neighborhood" => "",
	// 	"zipcode" => "",
	// 	"city" => "",
	// 	"complement" => "",
	// 	"state" => ""
	// ],
];



/*$conditional_discount = [
	"type" => "percentage", // "currency", "percentage"
	"value" => 500,
	"until_date" => "2024-12-20"
];*/


$bankingBillet = [
	"expire_at" => $gerar['data'],
	"message" => "Boleto Gerado com sucesso!",
	"customer" => $customer,
];

$payment = [
	"banking_billet" => $bankingBillet
];

$body = [
	"items" => $items,
	"payment" => $payment
];

try {
	$api = new EfiPay($options);
	$response = $api->createOneStepCharge($params = [], $body);
    header("Location: ".$response['data']['link']);
   	//print_r("<pre>" . json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "</pre>");
	$codigo = json_encode($response['data']);
	$codigo2 = json_decode($codigo);
	$id_efi = $codigo2->charge_id;
	$cliente_id = $cliente['id'];
	

	// insere Id boleto na tabela de pagamentos
	$sqlCobranca = "INSERT INTO pagamento (id_usuario,id_efi, data_venc) VALUES( '$cliente_id','$id_efi','$vencimento')";
	$inserirCobranca = $conn->query($sqlCobranca) or die($mysqli->error);
	

} catch (EfiException $e) {
	print_r($e->code . "<br>");
	print_r($e->error . "<br>");
	print_r($e->errorDescription) . "<br>";
} catch (Exception $e) {
	print_r($e->getMessage());
}

}

?>