<div class="row">
              <div class="col-md-12">
                <div class="card mb-0">
                  <div class="card-body">
                      <ul class="nav nav-pills" style="margin:5px; float:right;">
                      <li class="nav-item" >
                        <a class="nav-link active"  href="gerarBoleto.php">Gerar Boleto </a>
                      </li>
                     
                    </ul>
                    <ul class="nav nav-pills">
                    
                      <li class="nav-item">
                        <a class="nav-link active" href="addClientes.php">Cadastrar Clientes</a>
                      </li>

                      <li class="nav-item">
                        <a class="nav-link" href="painel.php">Listar Clientes</a>
                      </li>
        
                    </ul>
                  </div>
                </div>
              </div>
            </div>